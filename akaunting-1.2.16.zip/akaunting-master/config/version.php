<?php

return [

    'name'      =>  'Akaunting',

    'code'      =>  'Recurring',

    'major'     =>  '1',

    'minor'     =>  '2',

    'patch'     =>  '16',

    'build'     =>  '',

    'status'    =>  'Stable',

    'date'      =>  '14-September-2018',

    'time'      =>  '12:30',

    'zone'      =>  'GMT +3',

];
